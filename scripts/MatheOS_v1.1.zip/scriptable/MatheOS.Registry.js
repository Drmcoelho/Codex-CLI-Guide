// MatheOS.Registry.js
const Sys = importModule("MatheOS.Mod.Sys");
const Text = importModule("MatheOS.Mod.Text");
const Med = importModule("MatheOS.Mod.Med");

const ROUTES = new Map([
  ["sys.status", Sys.status],
  ["sys.battery", Sys.battery],

  ["text.upper", Text.upper],
  ["text.lower", Text.lower],
  ["text.echo", Text.echo],

  ["med.na_corrigido", Med.na_corrigido],
  ["med.help", Med.help],
]);

function getHandler(route) {
  return ROUTES.get(route);
}

module.exports = { getHandler };
