// MatheOS.Mod.Sys.js

function ok(spoken, display, data = {}) {
  return { ok: true, spoken, display: display || spoken, data, actions: [], error: null, debug: {} };
}

async function status(req, ctx) {
  const bat = ctx.device.battery;
  const pct = (typeof bat === "number" && bat >= 0) ? Math.round(bat * 100) : null;

  const spoken = pct === null
    ? "Sistema ok."
    : `Sistema ok. Bateria ${pct} por cento.`;

  const display = [
    "MatheOS SYS",
    `Device: ${ctx.device.name} (${ctx.device.model})`,
    `OS: ${ctx.device.system} ${ctx.device.systemVersion}`,
    `Bateria: ${pct === null ? "indisponível" : pct + "%"}`
  ].join("\n");

  return ok(spoken, display, { batteryPercent: pct });
}

async function battery(req, ctx) {
  return status(req, ctx);
}

module.exports = { status, battery };
