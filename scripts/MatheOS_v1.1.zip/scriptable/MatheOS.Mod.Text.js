// MatheOS.Mod.Text.js

function ok(spoken, display, data = {}) {
  return { ok: true, spoken, display: display || spoken, data, actions: [], error: null, debug: {} };
}

function payloadFromRaw(raw) {
  const parts = String(raw || "").split(/\s+/);
  return parts.slice(2).join(" ").trim();
}

async function upper(req) {
  const payload = payloadFromRaw(req.input.raw) || req.input.raw;
  const out = String(payload).toUpperCase();
  return ok("Feito.", out, { out });
}

async function lower(req) {
  const payload = payloadFromRaw(req.input.raw) || req.input.raw;
  const out = String(payload).toLowerCase();
  return ok("Feito.", out, { out });
}

async function echo(req) {
  return ok("Ok.", req.input.raw, { raw: req.input.raw });
}

module.exports = { upper, lower, echo };
