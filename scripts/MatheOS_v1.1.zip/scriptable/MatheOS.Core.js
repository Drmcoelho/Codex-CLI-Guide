// MatheOS.Core.js
// Request normalization + paleta parsing + route building + dispatch.

const Utils = importModule("MatheOS.Utils");
const Registry = importModule("MatheOS.Registry");

function ReplyOk(spoken, display, data = {}, actions = []) {
  return { ok: true, spoken: spoken || "", display: display || spoken || "", data, actions, error: null, debug: {} };
}

function ReplyErr(code, message, spoken = "Erro.", display = "") {
  return { ok: false, spoken, display: display || message || spoken, data: {}, actions: [], error: { code, message }, debug: {} };
}

function normalizeRequest(input) {
  // Accept string OR dict.
  if (typeof input === "string") {
    return {
      schema: "matheos.v1",
      route: "",
      input: { raw: input },
      flags: { debug: false, silent: false, dry_run: false },
      source: { trigger: "direct" }
    };
  }

  const req = input || {};
  req.schema = req.schema || "matheos.v1";
  req.route = req.route || "";
  req.input = req.input || { raw: "" };
  req.flags = req.flags || { debug: false, silent: false, dry_run: false };
  return req;
}

function parsePalette(raw) {
  // Easy mode: "<domain> <verb> <payload...>"
  const n = Utils.norm(raw);
  const toks = Utils.tokens(n);
  const domain = toks[0] || "";
  const verb = toks[1] || "";
  const restOriginal = String(raw || "").split(/\s+/).slice(2).join(" ").trim();

  const domain2 = domain || Utils.guessDomain(toks);
  return { domain: domain2, verb, tokens: toks, restOriginal };
}

function buildRoute(domain, verb, tokens) {
  if (!domain) return "";

  if (domain === "sys") {
    if (verb === "status" || tokens.includes("status")) return "sys.status";
    if (verb === "battery" || tokens.includes("bateria")) return "sys.battery";
    return "sys.status";
  }

  if (domain === "text") {
    if (verb === "upper" || tokens.includes("maius") || tokens.includes("maiuscula")) return "text.upper";
    if (verb === "lower" || tokens.includes("minus") || tokens.includes("minuscula")) return "text.lower";
    if (verb === "echo") return "text.echo";
    return "text.echo";
  }

  if (domain === "med") {
    if (verb === "na_corrigido" || tokens.includes("sodio") || tokens.includes("corrigido")) return "med.na_corrigido";
    if (verb === "help") return "med.help";
    return "med.help";
  }

  return "";
}

async function dispatch(req, ctx) {
  const handler = Registry.getHandler(req.route);
  if (!handler) return ReplyErr("NO_ROUTE", `Rota não registrada: ${req.route}`, "Comando não suportado.");

  if (req.flags?.dry_run) {
    return ReplyOk(
      "Dry run ativado.",
      `Rota: ${req.route}\nInput: ${req.input.raw}`,
      { route: req.route, raw: req.input.raw }
    );
  }

  return await handler(req, ctx);
}

async function runGateway(opts) {
  const incoming = args.shortcutParameter;
  const req = normalizeRequest(incoming);

  const raw = String(req.input?.raw || "").trim();
  if (!raw) {
    const out = ReplyErr("EMPTY", "Entrada vazia.", "Diga um comando.", "Ex: sys status | text upper oi | med na_corrigido ...");
    Script.setShortcutOutput(out);
    Script.complete();
    return;
  }

  // Voice-controlled flags
  const rawN = Utils.norm(raw);
  req.flags.debug = req.flags.debug || rawN.includes("debug on");
  if (rawN.includes("debug off")) req.flags.debug = false;
  req.flags.silent = req.flags.silent || rawN.includes("silent on") || rawN.includes("silencioso");

  const parsed = parsePalette(raw);
  if (!req.route) req.route = buildRoute(parsed.domain, parsed.verb, parsed.tokens);

  const ctx = {
    app: opts?.app || "MatheOS",
    version: opts?.version || "1.0.0",
    parsed,
    now: new Date().toISOString(),
    device: {
      name: Device.name(),
      system: Device.systemName(),
      systemVersion: Device.systemVersion(),
      model: Device.model(),
      battery: Device.batteryLevel()
    }
  };

  let res = await dispatch(req, ctx);

  if (req.flags.debug) {
    res.debug = { route: req.route, parsed, device: ctx.device };
  }
  if (req.flags.silent) {
    res.spoken = "";
  }

  Script.setShortcutOutput(res);
  Script.complete();
}

module.exports = { runGateway };
