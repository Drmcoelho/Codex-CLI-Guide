// MatheOS.Mod.Med.js
const Utils = importModule("MatheOS.Utils");

function ok(spoken, display, data = {}) {
  return { ok: true, spoken, display: display || spoken, data, actions: [], error: null, debug: {} };
}

async function na_corrigido(req) {
  // Placeholder: detects numbers for future slot parsing
  const nums = Utils.extractNumbers(req.input.raw);

  return ok(
    "Módulo médico ativado.",
    `Entrada: ${req.input.raw}\nNúmeros detectados: ${nums.length ? nums.join(", ") : "(nenhum)"}`,
    { numbers: nums }
  );
}

async function help() {
  return ok(
    "Diga um comando médico.",
    "Ex: med na_corrigido glicose 300 sodio 135",
    { examples: ["med na_corrigido glicose 300 sodio 135"] }
  );
}

module.exports = { na_corrigido, help };
