// MatheOS.Utils.js

function norm(s) {
  return String(s || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .trim();
}

function tokens(s) {
  return norm(s)
    .replace(/[^\p{L}\p{N}\s]/gu, " ")
    .split(/\s+/)
    .filter(Boolean);
}

function guessDomain(toks) {
  const t = toks || [];
  if (t.includes("sistema") || t.includes("bateria") || t.includes("status")) return "sys";
  if (t.includes("texto") || t.includes("maiuscula") || t.includes("minuscula") || t.includes("upper") || t.includes("lower")) return "text";
  if (t.includes("calcular") || t.includes("paciente") || t.includes("sodio") || t.includes("glicose")) return "med";
  return "";
}

function extractNumbers(raw) {
  const m = String(raw || "").match(/\d+(?:[.,]\d+)?/g);
  if (!m) return [];
  return m.map(x => parseFloat(x.replace(",", "."))).filter(n => Number.isFinite(n));
}

module.exports = { norm, tokens, guessDomain, extractNumbers };
