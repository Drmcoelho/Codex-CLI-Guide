// MatheOS.Gateway.js
// Scriptable entrypoint called from Shortcuts (Run Script).
const Core = importModule("MatheOS.Core");
await Core.runGateway({
  app: "MatheOS",
  version: "1.0.0",
});
