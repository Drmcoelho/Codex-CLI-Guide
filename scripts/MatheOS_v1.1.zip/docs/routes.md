# Routes & Paleta (v1.1)

## Paleta (easy mode)
### SYS
- `sys status`
- `sys battery`

### TEXT
- `text upper <texto>`
- `text lower <texto>`
- `text echo <texto>`

### MED (placeholder v1)
- `med na_corrigido glicose 300 sodio 135`
- `med help`

### GPT (drivers via Shortcuts)
- `gpt codex`  → abre Codex
- `gpt voz`    → modo voz
- `gpt chat`   → inicia conversa
- `gpt perguntar <pergunta>` → usa driver de pergunta JSON

### AI (Gemini/ChatGPT, multimodal e melhoria de lógica)
- `ai classificar <comando>`   → retorna domain/route/slots/confidence
- `ai normalizar <comando>`    → retorna comando canônico
- `ai slots <comando>`         → extrai parâmetros
- `ai camera` / `ai imagem` / `ai arquivo` → ações multimodais (drivers Gemini)

---

## Route mapping (Scriptable local)
Scriptable (MatheOS.Core.js) resolve as rotas locais:
- `sys.status`
- `sys.battery`
- `text.upper`
- `text.lower`
- `text.echo`
- `med.na_corrigido` (placeholder)
- `med.help`

Para GPT/AI, o recomendado é **drivers no Shortcuts** chamados por `RUN_SHORTCUT`
(veja docs/ai_integrations.md e docs/actions_protocol.md).
