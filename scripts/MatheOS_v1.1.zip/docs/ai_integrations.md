# MatheOS — IA no Shortcuts (ChatGPT + Gemini)

Objetivo: usar as ações nativas dos apps **ChatGPT** e **Gemini** como “coprocessadores” do MatheOS.

## Estratégia recomendada (dividir pra conquistar)
- **Gemini** = *multimodal* (microfone/câmera/imagem/arquivo)
- **ChatGPT** = *estrutura & validação* (JSON estrito, refactor, roteamento, QA)

Você pode usar só um deles por vez, ou em pipeline.

---

## 1) Drivers (atalhos pequenos) — o segredo da robustez

Crie atalhos “drivers” de 1 ação cada, para você poder invocar via `RUN_SHORTCUT`
usando o `response.actions` (docs/actions_protocol.md).

### ChatGPT drivers (sugestão)
- **MatheOS GPT 01 - Perguntar JSON**
  - Usa: `New Chat Configuration` + `Pergunte ao ChatGPT`
  - Exige resposta **APENAS JSON**
  - Retorna Dictionary `response`
- **MatheOS GPT 02 - Abrir Codex**
  - Usa: `Abrir Codex`
- **MatheOS GPT 03 - Modo voz**
  - Usa: `Modo voz`
- **MatheOS GPT 04 - Iniciar conversa**
  - Usa: `Iniciar conversa com o ChatGPT`

### Gemini drivers (sugestão)
- **MatheOS Gemini 01 - Escrever comando**
  - Usa: `Escrever comando para o Gemini` (texto → resposta)
- **MatheOS Gemini 02 - Microfone**
  - Usa: `Abrir microfone para o Gemini`
- **MatheOS Gemini 03 - Live**
  - Usa: `Fale Live o Gemini`
- **MatheOS Gemini 04 - Imagem**
  - Usa: `Compartilhar imagem com o Gemini`
- **MatheOS Gemini 05 - Arquivo**
  - Usa: `Compartilhar arquivo com o Gemini`
- **MatheOS Gemini 06 - Câmera**
  - Usa: `OpenCameraWithGeminiShortTitle` (ou equivalente)

---

## 2) Prompts JSON (cole nos drivers)

### A) Classificador de domínio/rota (Root fallback)
Peça APENAS JSON:
```json
{"domain":"sys|text|med|ai|dev","route":"...","slots":{},"confidence":0.0,"alternatives":[]}
```

### B) Normalizador de comando (ditado → paleta)
Entrada: texto livre. Saída: paleta canônica, ex: `sys status`.

### C) Extrator de slots (parâmetros)
Saída:
```json
{"route":"med.na_corrigido","slots":{"glicose":300,"na":135}}
```

### D) Refactor de shortcut (melhorar lógica)
Entrada: descrição do bug + print/export.  
Saída: diagnóstico + plano de refactor em passos + pontos de instrumentação.

Os templates prontos estão em `prompts/`.

---

## 3) Onde plugar no MatheOS
- Root Kernel: se não classificar com confiança, chama `MatheOS GPT 01 - Perguntar JSON` (ou Gemini TXT) para classificar.
- Subkernels: podem chamar IA para extrair slots e então repassar para Scriptable/local.

---

## 4) Boas práticas
- Sempre exigir **JSON estrito** (sem Markdown).
- Se IA devolver lixo, use regex no Shortcuts para capturar o bloco `{ ... }`.
- Logue em “Shadow Mode”: rode IA em paralelo e grave sugestão; só aplica depois.
