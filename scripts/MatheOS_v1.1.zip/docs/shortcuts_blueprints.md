# Shortcuts Blueprints — MatheOS multi-kernel (v1.1)

Este blueprint descreve o setup “dividir pra conquistar”:
- 1 Root Kernel
- N Subkernels
- Drivers para IA (ChatGPT/Gemini)
- Uma lib para executar `response.actions`

---

## A) MatheOS 00 - Entrada (Siri)
1. Dictate Text → `rawText`
2. If `rawText` vazio → Ask for Input (Text) → `rawText`
3. Run Shortcut: **MatheOS 01 - Lib BuildRequest** (input: `rawText`) → `request`
4. Run Shortcut: **MatheOS 10 - Kernel (Root Router)** (input: `request`) → `response`

5. (Opcional) Run Shortcut: **MatheOS 02 - Lib ExecuteActions** (input: `response`)
   - Isso permite que módulos peçam execução extra (abrir apps, chamar atalhos etc.)

6. Get `spoken` → Speak Text (se não vazio)
7. Get `display` → Show Result

---

## B) MatheOS 01 - Lib BuildRequest
Entrada: texto
Saída: Dictionary request

Campos mínimos:
- schema = `matheos.v1`
- route = "" (vazio; kernel define)
- input.raw = texto
- flags = {debug:false, silent:false, dry_run:false}

---

## C) MatheOS 10 - Kernel (Root Router)
Decide domínio com base no primeiro token:
- `sys ...` → Subkernel SYS
- `text ...` → Subkernel TEXT
- `med ...` → Subkernel MED
- `gpt ...` → Subkernel GPT
- `ai ...` → Subkernel AI

Fallback (se não vier prefixo):
- keywords → (sys/text/med)
- se ambíguo → chama driver `MatheOS GPT 01 - Perguntar JSON` com prompt classifier (shadow mode opcional)

---

## D) Subkernels (exemplos)
### MatheOS 11 - Kernel SYS
- define route (sys.status/sys.battery)
- chama Scriptable: **MatheOS.Gateway.js**
- retorna response

### MatheOS 12 - Kernel TEXT
- define route (text.upper/text.lower/text.echo)
- chama Scriptable Gateway

### MatheOS 13 - Kernel MED
- define route (med.na_corrigido/med.help)
- chama Scriptable Gateway

### MatheOS 14 - Kernel GPT (drivers)
- `gpt codex` → Run Shortcut `MatheOS GPT 02 - Abrir Codex`
- `gpt voz` → Run Shortcut `MatheOS GPT 03 - Modo voz`
- `gpt chat` → Run Shortcut `MatheOS GPT 04 - Iniciar conversa`
- `gpt perguntar ...` → Run Shortcut `MatheOS GPT 01 - Perguntar JSON`

### MatheOS 20 - Kernel AI (drivers)
- `ai classificar ...` → Driver GPT/Gemini TXT com prompt classifier
- `ai normalizar ...` → Driver GPT/Gemini TXT com prompt normalize
- `ai slots ...` → Driver GPT/Gemini TXT com prompt slots
- `ai camera/imagem/arquivo` → Drivers Gemini multimodais

---

## E) MatheOS 02 - Lib ExecuteActions
Implementa `response.actions` (ver docs/actions_protocol.md).
