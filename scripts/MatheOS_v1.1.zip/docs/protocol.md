# MatheOS Protocol — Request/Response (matheos.v1)

## Request (Dictionary)
Minimum required fields:

- schema: "matheos.v1"
- route: string (can be empty; Scriptable Core will infer from paleta)
- input.raw: string
- flags: { debug: bool, silent: bool, dry_run: bool }

Example:
```json
{
  "schema": "matheos.v1",
  "route": "",
  "input": { "raw": "sys status" },
  "flags": { "debug": false, "silent": false, "dry_run": false },
  "source": { "trigger": "siri", "shortcut": "MatheOS 00 - Entrada (Siri)" }
}
```

## Response (Dictionary)
- ok: boolean
- spoken: string (to be spoken by Shortcuts)
- display: string (to be shown by Shortcuts)
- data: dict (free payload)
- actions: list (optional future pipeline)
- error: {code,message} (if ok=false)
- debug: dict (only filled when debug=true)

Example:
```json
{
  "ok": true,
  "spoken": "Sistema ok. Bateria 82 por cento.",
  "display": "MatheOS SYS\nDevice: ...",
  "data": { "batteryPercent": 82 },
  "actions": [],
  "error": null,
  "debug": {}
}
```
