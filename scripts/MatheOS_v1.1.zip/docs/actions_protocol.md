# MatheOS — Actions Protocol (response.actions)

O campo `response.actions` permite que um módulo (Scriptable ou IA) *sugira* uma sequência de passos
que o Shortcuts executará. Assim, o “cérebro” pode morar fora do atalho, mas a execução fica no atalho.

## Estrutura
`actions` é uma lista de objetos:

```json
{
  "type": "RUN_SHORTCUT | OPEN_APP | SPEAK | SHOW_RESULT | MENU",
  "name": "nome do atalho ou app",
  "input": {},
  "text": "texto para falar/mostrar",
  "items": ["opção A","opção B"],
  "meta": {}
}
```

### Tipos recomendados (v1)
- `RUN_SHORTCUT`  
  - `name`: nome do atalho a executar  
  - `input`: Dictionary para o atalho
- `OPEN_APP`  
  - `name`: nome do app (ex: "ChatGPT", "Gemini")
- `SPEAK`  
  - `text`: texto para Siri falar
- `SHOW_RESULT`  
  - `text`: texto para mostrar
- `MENU`  
  - `items`: lista de opções  
  - `meta.onSelect`: (conceitual) rota/atalho para cada item

## Por que isso resolve a vida?
1) Você cria “drivers” pequenos (atalhos de 1 responsabilidade).  
2) IA/Scriptable só devolvem `actions` que chamam esses drivers.  
3) Seu Kernel vira estável: nunca mais refaz tudo.

## Implementação no Shortcuts (macro)
Crie: **MatheOS 02 - Lib ExecuteActions**

Entrada: `response` (Dictionary)

Pseudo‑fluxo:
1. `actions = response.actions` (Get Value)
2. Repeat with each `action` in `actions`
   - If `action.type == RUN_SHORTCUT`: Run Shortcut `action.name` com `action.input`
   - If `OPEN_APP`: Open App `action.name`
   - If `SPEAK`: Speak Text `action.text`
   - If `SHOW_RESULT`: Show Result `action.text`
   - If `MENU`: Choose from Menu `action.items` e decida o próximo passo
3. Output: último resultado (se você quiser encadear)

> Observação: para ações específicas (ex: **ChatGPT → Abrir Codex**),
o jeito robusto é ter um atalho driver **MatheOS GPT 02 - Abrir Codex** e chamar via `RUN_SHORTCUT`.
