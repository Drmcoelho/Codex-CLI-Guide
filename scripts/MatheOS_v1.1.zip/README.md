# MatheOS v1.1 (Shortcuts + Scriptable) — Multi‑Kernel + IA (ChatGPT/Gemini)

Este pacote é um *starter kit* para um “sistema operacional” de atalhos:
- **Root Kernel** (roteia por domínio: `sys`, `text`, `med`, `ai`, `gpt`)
- **Subkernels** (um por domínio)
- **Scriptable Runtime** (Core + Registry + Modules) para lógica local
- **IA via Shortcuts**: integração **nativa** com ações do app **ChatGPT** e **Gemini** (multimodal)

> Princípio: **um único contrato** de entrada/saída (Request/Response).  
> Isso permite que “atalhos chamem atalhos” e que você plugue IA sem quebrar o resto.

## Paleta (modo fácil)
- `sys status`
- `text upper <texto>`
- `text lower <texto>`
- `med na_corrigido glicose 300 sodio 135`
- `gpt codex` | `gpt voz` | `gpt perguntar <pergunta>`
- `ai classificar <comando>` | `ai normalizar <comando>` | `ai slots <comando>`
- `ai camera` | `ai imagem` | `ai arquivo`

## Onde olhar
- `docs/protocol.md` — contrato Request/Response (MatheOS)
- `docs/routes.md` — rotas e exemplos
- `docs/shortcuts_blueprints.md` — blueprint do Root Kernel + subkernels
- `docs/actions_protocol.md` — protocolo `response.actions` + como executar via Shortcuts
- `docs/ai_integrations.md` — como usar **ChatGPT** e **Gemini** como coprocessadores

## Scriptable
Copie os arquivos de `scriptable/` para o Scriptable (mesmo diretório).  
Use o script `MatheOS.Gateway.js` no “Run Script” do Shortcuts.

Versão: **1.1.0**
